/*
 * GameState.cpp
 *
 *      Author: scarbors
 */

#include "GameState.h"
#include "Tract.h"

namespace AIProj
{

  GameState::GameState ()
  {

  }

  GameState::~GameState ()
  {
	  //Using shared_ptrs so no need to manually delete
  }

} /* namespace AIProj */
